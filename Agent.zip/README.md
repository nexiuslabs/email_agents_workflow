# aigent
Crew AI Agents get context from knowledge database and generate a message based on knowledge.
